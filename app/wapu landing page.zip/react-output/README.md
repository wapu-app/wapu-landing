# Cómo integrar el rediseño de /lat en el codebase

## 1. Reemplazar `lat-landing.tsx`

Reemplazá `wapu-landing/app/lat/lat-landing.tsx` con el archivo `lat-landing.tsx` de esta carpeta.

Notas:
- El componente declara `"use client"` porque usa `useEffect` para animaciones y refs al DOM.
- Mantiene los mismos imports (`next/image`, `next/link`) y la constante `WAPU_SIGNUP_URL`.
- `SHOW_BUY_BTC_MODULE` queda como flag en false (igual que estaba).

`page.tsx` no necesita cambios — sigue importando `LatLanding`.

## 2. Reemplazar / pegar los estilos en `globals.css`

En `wapu-landing/app/globals.css`, borrá todo desde `.lat-page {` hasta el final del archivo (el bloque viejo de `/lat` + el media query final `@media (prefers-reduced-motion: reduce)`), y pegá el contenido de `lat-styles.css` de esta carpeta.

Lo que queda intacto al inicio de `globals.css`:

```css
@import "tailwindcss";

:root {
  --background: #0a0712;
  --foreground: #f3f4f6;
}

@theme inline {
  --color-background: var(--background);
  --color-foreground: var(--foreground);
  --font-sans: var(--font-geist-sans);
  --font-mono: var(--font-geist-mono);
}

* {
  box-sizing: border-box;
}

html,
body {
  margin: 0;
  padding: 0;
  background: var(--background);
  color: var(--foreground);
}

body {
  font-family: var(--font-geist-sans), ui-sans-serif, system-ui, -apple-system, Segoe UI, Roboto, Helvetica,
    Arial, sans-serif;
}

.electric-line { /* ...el bloque que usás en otras páginas... */ }
.electric-line::after { /* ... */ }
@keyframes electric-flow { /* ... */ }
```

Y desde `.lat-page {` (y todo lo que tenga prefijo `.lat-`, `.r-fade`, `.r-stagger`, los `@keyframes r-*`, `lat-*` y los media queries finales), reemplazalo por el contenido de `lat-styles.css`.

## 3. Assets necesarios en `/public`

Casi todo ya está, pero **agregá el nuevo logo** que viene en esta carpeta:

- ✅ `public/audience/bitcoiner-autocustodia-argentina.webp` (ya está)
- ✅ `public/audience/freelancer-cripto-barrio.webp` (ya está)
- ✅ `public/audience/builder-latam-taller.webp` (ya está)
- ✅ `public/lat/video/placeholder-video.mp4` (ya está)
- 🆕 `public/wapu-logo.png` ← copiá `wapu-logo.png` de esta carpeta a `public/`

El logo se usa en la banda **Escrow [logo]** (sección Escrow). En navbar y mockup del teléfono el wordmark sigue siendo texto italic "wapu" — si querés que también ahí use la imagen, reemplazá `<span className="lat-brand-mark">wapu</span>` y `<span className="lat-phone-logo">wapu</span>` por `<Image>` apuntando a `/wapu-logo.png`.

## 4. Notas finales

- Las animaciones de scroll usan `IntersectionObserver` + fallback sobre `scroll`, así que arrancan apenas el componente monta.
- El `useLatAnimations()` hook limpia todos los listeners en su `return` — está listo para hot-reload.
- La paleta de colores se mantiene (variables `--lat-pink`, `--lat-purple`, `--lat-blue`, `--lat-electric`, `--lat-electric-cold`).
- Si querés cambiar copy / pasos / FAQs, todo está como array de objetos al tope del archivo (`operationSteps`, `audience`, `helpItems`, `contactItems`, `videoBullets`).
